# Healthcare-Database-creation-from-scratch
Creating a healthcare database starting from modelling EER models, relational mapping and implementing it in MySQL, Python and MongoDB  
